# LanderController
 Skeleton code for KV5002
 (1) use make all to compile 
 ```
 $ make all
 ```
 (2) If the code is complied successfully, run the programme using
```
 $ ./controller 65200 65250
 ```
