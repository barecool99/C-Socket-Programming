# LunarLander
Physics model for Lunar Lander for kv5002
use the following commands to compile and run the program
```
$ make clean
$ make 
$ java -jar LunarLander.jar
```
