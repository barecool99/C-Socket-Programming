# LanderDash
use the following commands to compile and run the program
```
$ make clean
$ make 
$ java -jar LanderDash.jar
```
